%% Define state-space matrices for rotary flexible beam
clc; clear all;

%Define physical values
Jr=0.0020841;
Jb=0.00380382167;
Kb=1.3;
Br=0.0150;
Bb=0;


%Write State Space matrices
A = [0 0 1 0;
    0 0 0 1;
    0 Kb/Jr -Br/Jr 0;
    0 -Kb*(Jr+Jb)/Jr/Jb Br/Jr 0];

B = [0 0 1/Jr -1/Jr]';

C = [1 0 0 0;
    0 0 0 0];

D = zeros(2,1);

%Adjust State Space matrices for voltage input rather than torque input
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;
eta_g = 0.90;
eta_m = 0.69;

A_old = A;
B_old = B;
B = eta_g*Kg*eta_m*kt/Rm*B_old;
A(3,3) = A_old(3,3) - B_old(3)*eta_g*Kg^2*eta_m*kt*km/Rm;
A(4,3) = A_old(4,3) - B_old(4)*eta_g*Kg^2*eta_m*kt*km/Rm;
%% Controllability & Observability
cont=ctrb(A,B);
rk_cont=rank(cont);
obs=obsv(A,C);
rk_obs=rank(obs);

%% LQR Feedback
Q = diag([150,1,1,5]);
R=1;
%Used LQR command in place of the care command (to solve Riccati)
K = lqr(A,B,Q,R);

%% Plotting
figure(1)
plot(data_theta(:,1),data_theta(:,2));
hold on
plot(data_theta(:,1),data_theta(:,3),'r');
legend('desired rotor base angle','measured rotor base angle')
xlabel('time')
ylabel('rotor base angle, \theta (degrees)')
hold off

figure(2)
plot(data_alpha(:,1),data_alpha(:,2))
xlabel('time')
ylabel('flexible beam deflection angle, \alpha (degrees)')
%% Luenberger Design

observer_poles=[-20 -25 -30 -35];
%Because of the duality between controllability and observability, we can
%use the same technique used to find the control gain, K, to find the
%observer gain, L.
L=place(A',C',observer_poles);
L=L';

init_observer=[0;0;0;0];