%% Define state-space matrices for rotary pendulum (lab 2 - linearized around stable equilibrium)
clc; clear all;

Jp=0.001199;
Jr=0.000998;
Bp=0;
Br=0.137;
Lp=0.3365;
Lr=0.2159;
Mp=0.1270;
Mr=0.2570;
g=9.81;

%--------------------------------------------------------------------------
%Write State Space matrices here:
A = 0;

B = 0;

C = 0;

D = 0;
%--------------------------------------------------------------------------
%Adjusts state-space matrices for voltage input rather than torque input
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;

A(3,3) = A(3,3) - Kg^2*kt*km/Rm*B(3);
A(4,3) = A(4,3) - Kg^2*kt*km/Rm*B(4);
B = Kg * kt * B / Rm;