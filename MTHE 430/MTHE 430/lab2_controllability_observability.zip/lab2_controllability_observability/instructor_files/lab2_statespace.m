%% Pendulum State Space (lab 2 - linearized around stable equilibrium)
% clc; clear all;

Jp = 0.001199;
Jr=0.000998;
Bp=0.00001;
Br=0.137;
Lp=0.3365;
Lr=0.2159;
Mp=0.1270;
Mr=0.2570;
g=9.81;
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;

% State Space Representation
Jt = Jr*Jp + Mp*(Lp/2)^2*Jr + Jp*Mp*Lr^2;
A = [0 0 1 0;
     0 0 0 1;
     0 Mp^2*(Lp/2)^2*Lr*g/Jt -Br*(Jp+Mp*(Lp/2)^2)/Jt Mp*(Lp/2)*Lr*Bp/Jt;
     0 -Mp*g*(Lp/2)*(Jr+Mp*Lr^2)/Jt Mp*(Lp/2)*Lr*Br/Jt -Bp*(Jr+Mp*Lr^2)/Jt];

B = [0; 0; (Jp+Mp*(Lp/2)^2)/Jt; -Mp*(Lp/2)*Lr/Jt];
C = [1 0 0 0;
    0 0 0 0];
D = zeros(2,1);

% Add actuator dynamics
A(3,3) = A(3,3) - Kg^2*kt*km/Rm*B(3);
A(4,3) = A(4,3) - Kg^2*kt*km/Rm*B(4);
B = Kg * kt * B / Rm;

%% Cont and Obs
Cont = ctrb(A,B);
Obs = obsv(A,C);
rank1 = rank(Cont);
rank2 = rank(Obs);
kernel = null(Obs);
null(Obs)

%% Plot state-space & physical system response
figure(1)
plot(data_alpha(:,1), data_alpha(:,2))
hold on
plot(data_alpha(:,1), data_alpha(:,3),'r')
legend('State-space model','Physical system')
xlabel('time')
ylabel('pendulum angle, \alpha (radians)')

figure(2)
plot(data_theta(:,1),data_theta(:,2))
hold on
plot(data_theta(:,1),data_theta(:,3),'r')
legend('State-space model','Physical system')
xlabel('time')
ylabel('rotor base angle, \theta (radians)')

%% Save state-space response (observability test)
figure(1)
save('data_theta_motor_encoder_init_cond_0.mat','data_theta')
plot(data_theta(:,1),data_theta(:,2),'r')
hold on
plot(data_alpha(:,1), data_alpha(:,2),'b')
legend('\theta','\alpha')
