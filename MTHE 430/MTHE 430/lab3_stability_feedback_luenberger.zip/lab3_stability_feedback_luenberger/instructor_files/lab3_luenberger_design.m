%% Lab 3 state space - linearized around stable equilibrium
% clc; clear all;

Jp = 0.001199;
Jr=0.000998;
Bp=0.0024;
Br=0.0024;
Lp=0.3365;
Lr=0.2159;
Mp=0.1270;
Mr=0.2570;
g=9.81;
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;

% State Space Representation
Jt = Jr*Jp + Mp*(Lp/2)^2*Jr + Jp*Mp*Lr^2;
A = [0 0 1 0;
     0 0 0 1;
     0 Mp^2*(Lp/2)^2*Lr*g/Jt -Br*(Jp+Mp*(Lp/2)^2)/Jt Mp*(Lp/2)*Lr*Bp/Jt;
     0 -Mp*g*(Lp/2)*(Jr+Mp*Lr^2)/Jt Mp*(Lp/2)*Lr*Br/Jt -Bp*(Jr+Mp*Lr^2)/Jt];

B = [0; 0; (Jp+Mp*(Lp/2)^2)/Jt; -Mp*(Lp/2)*Lr/Jt];
C = [1 0 0 0;
    0 0 0 0];
D = zeros(2,1);
%inital conditions
E = [0;0;0;0];

% Add actuator dynamics
A(3,3) = A(3,3) - Kg^2*kt*km/Rm*B(3);
A(4,3) = A(4,3) - Kg^2*kt*km/Rm*B(4);
B = Kg * kt * B / Rm;

%% Luenberger design
feedback_poles=[-2.8+2.86*1i -2.8-2.86*1i -30 -40];
%Place observer poles at least 5 times farther to the left than the domant
%feedback poles (the poles closest to the imaginary axis, as their effects
%last the longest)
observer_poles=[-5 -6 -7 -8];
%Because of the duality between controllability and observability, we can
%use the same technique used to find the control gain, K, to find the
%observer gain, L.
L=place(A',C',observer_poles);
L=L';
K=place(A,B,feedback_poles);

init_system=[0;0;0;0];
init_observer=[0;3.142;0;0];


% a=poly(A);
% syms s
% c=sym2poly((s+50)*(s+60)*(s+70)*(s+80));
% L2=inv(obsv(A,C)) * inv([1 0 0 0; a(2) 1 0 0; a(3) a(2) 1 0; a(4) a(3) a(2) 1]) * [c(2)-a(2);c(3)-a(3);c(4)-a(4);c(5)-a(5)];
%% Plotting state space and estimate state data
cut_data=1;

figure(1)
plot(theta.time(cut_data:end,1),theta.signals.values(cut_data:end,1))
hold on
plot(theta.time(cut_data:end,1),theta.signals.values(cut_data:end,2),'-.r')
title('Comparing Actual & Estimated Rotor Angle, \theta');
legend('rotor base angle, \theta','estimated rotor base angle')
hold off

figure(2)
plot(alpha.time(cut_data:end,1),alpha.signals.values(cut_data:end,1))
hold on
plot(alpha.time(cut_data:end,1),alpha.signals.values(cut_data:end,2),'-.r')
hold off
legend('pendulum angle, \alpha','estimated pendulum angle')
title('Comparing Actual & Estimated Pendulum Angle, \alpha');

figure(3)
plot(thetadot.time(cut_data:end,1),thetadot.signals.values(cut_data:end,1))
hold on
plot(thetadot.time(cut_data:end,1),thetadot.signals.values(cut_data:end,2),'-.r')
hold off
legend('rotor base angluar velocity','estimated rotor base anglular velocity')
title('Comparing Actual & Estimated Rotor Angular Velocity');

figure(4)
plot(alphadot.time(cut_data:end,1),alphadot.signals.values(cut_data:end,1))
hold on
plot(alphadot.time(cut_data:end,1),alphadot.signals.values(cut_data:end,2),'-.r')
hold off
legend('pendulum anglular velocity, \alpha','estimated pendulum anglular velocity')
title('Comparing Actual & Estimated Pendulum Angular Velocity');
