%% Lab 3 State Space - linearized about unstable equilibrium
% clc; clear all;

Jp = 0.001199;
Jr=0.000998;
Bp=0.0024;
Br=0.0024;
Lp=0.3365;
Lr=0.2159;
Mp=0.1270;
Mr=0.2570;
g=9.81;
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;

% State Space Representation
Jt = Jr*Jp + Mp*(Lp/2)^2*Jr + Jp*Mp*Lr^2;
A = [0 0 1 0;
     0 0 0 1;
     0 Mp^2*(Lp/2)^2*Lr*g/Jt -Br*(Jp+Mp*(Lp/2)^2)/Jt -Mp*(Lp/2)*Lr*Bp/Jt;
     0 Mp*g*(Lp/2)*(Jr+Mp*Lr^2)/Jt -Mp*(Lp/2)*Lr*Br/Jt -Bp*(Jr+Mp*Lr^2)/Jt];

B = [0; 0; (Jp+Mp*(Lp/2)^2)/Jt; Mp*(Lp/2)*Lr/Jt];
C = [1 0 0 0;
    0 1 0 0];
D = zeros(2,1);

% Add actuator dynamics
A(3,3) = A(3,3) - Kg^2*kt*km/Rm*B(3);
A(4,3) = A(4,3) - Kg^2*kt*km/Rm*B(4);
B = Kg * kt * B / Rm;

%% Open-loop stability
open_poles=eig(A);
%% Feedback gain
a=poly(A);
tilde_A = [0 1 0 0;
    0 0 1 0;
    0 0 0 1;
    -a(5) -a(4) -a(3) -a(2)];
tilde_B = [0;0;0;1];
syms s
b=sym2poly((s+2.8-2.86*i)*(s+2.8+2.86*i)*(s+30)*(s+40));
tilde_K = [-a(5)+b(5) -a(4)+b(4) -a(3)+b(3) -a(2)+b(2)];
T=ctrb(tilde_A,tilde_B)*inv(ctrb(A,B));
K=tilde_K*T;
%% Feedback Controller
figure(1)
plot(data_theta(:,1),data_theta(:,2));
hold on
plot(data_theta(:,1),data_theta(:,3),'r')
legend('Desired rotary base angle, \theta_d','Measured rotary base angle, \theta')
figure(2)
plot(data_alpha(:,1),data_alpha(:,2),'r')
legend('Measured pendulum angle, \alpha')