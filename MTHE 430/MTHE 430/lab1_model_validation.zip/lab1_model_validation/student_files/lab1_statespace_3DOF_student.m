%% Define state-space matrices for 3DOF rotary flexible beam (lab 1)
clc; clear all;

%--------------------------------------------------------------------------
%Enter in your Kb here
Kb=0;

%--------------------------------------------------------------------------
%Define physical system parameters
Jr=0.0020841;
Jb=0.00380382167;
Br=0.0150;

spring_factor=2;
Kb1=spring_factor*Kb;
Kb2=spring_factor*Kb;
Bb=0.0150;
Bb1=(1/sqrt(spring_factor*0.25))*Bb;
Bb2=0;

%--------------------------------------------------------------------------
%Write State Space matrices here:
A = 0;

B = 0;

C = 0;

D = 0;
%--------------------------------------------------------------------------
%Adjusts state-space matrices for voltage input rather than torque input
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;
eta_g=0.90;
eta_m=0.69;

A(4,4)=A(4,4)-eta_g*eta_m*(Kg^2)*kt*km*B(4)/Rm;
A(5,4)=A(5,4)-eta_g*eta_m*(Kg^2)*kt*km*B(5)/Rm;
A(6,4)=A(6,4)-(Kg^2)*kt*km*B(6)/Rm;
B=eta_g*(Kg*kt/Rm)*B;