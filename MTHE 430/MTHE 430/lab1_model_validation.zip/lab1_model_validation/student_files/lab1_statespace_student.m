%% Define state-space matrices for rotary flexible beam (lab 1)
clc; clear all;

%Defines physical system parameters
Jr=0.0020841;
Jb=0.0038038;
Br=0.015;
Bb=0;

%--------------------------------------------------------------------------
%Enter in your Kb here
Kb=0;

%--------------------------------------------------------------------------
%Write State Space matrices here:
A = 0;

B = 0;

C = 0;

D = 0;
%--------------------------------------------------------------------------
%Adjusts state-space matrices for voltage input rather than torque input
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;
eta_g = 0.90;
eta_m = 0.69;

A_old = A;
B_old = B;
B = eta_g*Kg*eta_m*kt/Rm*B_old;
A(3,3) = A_old(3,3) - B_old(3)*eta_g*Kg^2*eta_m*kt*km/Rm;
A(4,3) = A_old(4,3) - B_old(4)*eta_g*Kg^2*eta_m*kt*km/Rm;