clc; clear all;
load('3DOFmodel_stepresponse2to0_data.mat');
load('2DOFmodel_physicalsystem_stepresponse2to0_data');

figure(1)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha_total(:,1),data_alpha_total(:,2),'m');
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model','3DOF model','physical system')
hold off

clear data_alpha data_alpha_total
load('3DOFmodel_stepresponse5to0_data.mat');
load('2DOFmodel_physicalsystem_stepresponse5to0_data');

figure(2)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha_total(:,1),data_alpha_total(:,2),'m');
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model','3DOF model','physical system')
hold off

figure(3)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model','physical system')
hold off

clear data_alpha data_alpha_total
load('3DOFmodel_stepresponse10to0_data.mat');
load('2DOFmodel_physicalsystem_stepresponse10to0_data');

figure(4)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha_total(:,1),data_alpha_total(:,2),'m');
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model','3DOF model','physical system')
hold off

figure(5)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model','physical system')
hold off
