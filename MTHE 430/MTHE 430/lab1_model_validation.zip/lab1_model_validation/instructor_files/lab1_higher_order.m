clc; clear all;

%Define physical values
Jr=0.0020841;
Jb=0.0038038;
Br=0.015;
Bb=0.015;
Bb1=sqrt(2)*Bb;
Bb2=0;

Jb1=(1/4)*Jb;
Jb2=Jb1;
Kb=1.3;
spring_factor=2;
Kb1=spring_factor*Kb;
Kb2=spring_factor*Kb;

%Write State Space matrices
A = [0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 Kb1/Jr 0 (-Br/Jr) (Bb1/Jr) 0;
    0 (-Kb1/Jr-Kb1/Jb1) (Kb2/Jb1) (Br/Jr) (-Bb1/Jr-Bb1/Jb1) (Bb2/Jb1);
    0 (Kb1/Jb1) (-Kb2/Jb1-Kb2/Jb2) 0 (Bb1/Jb1) (-Bb2/Jb1-Bb2/Jb2)];
B = [0;0;0;(1/Jr);(-1/Jr);0];
C=[1 0 0 0 0 0;
    0 1 0 0 0 0;
    0 0 1 0 0 0];
D=zeros(3,1);

%Adjust State Space matrices for voltage input rather than torque input
Kg=70;
kt=0.0077;
km=0.0077;
Rm=2.6;
eta_g=0.90;
eta_m=0.69;

A(4,4)=A(4,4)-eta_g*eta_m*(Kg^2)*kt*km*B(4)/Rm;
A(5,4)=A(5,4)-eta_g*eta_m*(Kg^2)*kt*km*B(5)/Rm;
A(6,4)=A(6,4)-(Kg^2)*kt*km*B(6)/Rm;
B=eta_g*(Kg*kt/Rm)*B;

%% Plotting after running Simulink
% plot(data_theta(:,1),data_theta(:,2),'b');
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha1(:,1),data_alpha1(:,2),'m');
plot(data_alpha1(:,1),(data_alpha(:,2)+data_alpha1(:,2)),'g','LineWidth',2);
legend('\alpha_1','\alpha_2','\alpha_1+\alpha_2');

%% Save Simulink block diagram as eps
fig = get_param('test','Handle');
saveas(fig,'higher_order_simulink_model.eps')