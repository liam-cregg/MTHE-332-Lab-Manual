figure(1)
plot(data_theta(:,1),data_theta(:,2),'r');
hold on
plot(data_theta(:,1),data_theta(:,3),'b');
legend('2DOF model rotor base angle','physical system rotor base angle')
hold off

figure(2)
plot(data_alpha(:,1),data_alpha(:,2),'r');
hold on
plot(data_alpha(:,1),data_alpha(:,3),'b');
legend('2DOF model beam deflection angle','physical system beam deflection angle')
hold off
